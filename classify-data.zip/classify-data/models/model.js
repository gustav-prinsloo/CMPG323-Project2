const mongoose = require('mongoose')


const mongodbURI = 'mongodb+srv://Gus:12345@cluster0.mfng8.mongodb.net/Proj2?retryWrites=true&w=majority'


mongoose.connect(mongodbURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})


const mongooseConnection = mongoose.connection



mongooseConnection.on('error', function(mongooseConnectionError){
    console.log(`Mongoose Connection Error: ${mongooseConnectionError}`)
})


mongooseConnection.on('open', function(){
    console.log(`Successfully connected to DB`)
})



const metaSchema = new mongoose.Schema({
    file_Name: String,
    name_Surname: String,
    contact_Number: String,
    email_Address: String,
    id_Number: String, 
    dob: String,
})



const fileModel = new mongoose.model('files', metaSchema)


module.exports = fileModel