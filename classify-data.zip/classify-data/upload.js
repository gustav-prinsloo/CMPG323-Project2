const router = require('express').Router()

router.post('/', (req, res) => {

    if (req.files.file.name.split(".")[1] == 'txt' || req.files.file.name.split(".")[1] == 'csv'){
        let uploadedFile = req.files.file



        uploadedFile.mv('./uploads/' + uploadedFile.name, function(error){
            if (error) {
                console.log(error)               
            }

            const fs = require('fs')
            const path = require('path')
        
            const readStream = fs.createReadStream(path.join(__dirname, './uploads', uploadedFile.name))

            let data = ''
    
            readStream.on('data', (chunk) => {
                data += chunk
            })
        



            readStream.on('end', function(){
                let name_Surname = data.match('[A-Z]{1}[a-z]+[ ][A-Z]{1}[a-z]+')
                let contact_Number = data.match('[0-9]{3}[ ]?[0-9]{3}[ ]?[0-9]{4}')
                let email_Address = data.match('[a-zA-Z0-9]+[.-]?[a-zA-Z0-9]+@[a-zA-Z]+[.]?[a-z]+[.]?[a-z]+')
                let id_Number = data.match('[0-9]{6}[ ]?[0-9]{4}[ ]?[0-9]{3}')
                let dob = data.match('[0-9]{4}[-/]{1}[0-9]{2}[-/]{1}[0-9]{2}')
               
                res.json({
                    heading: 'We found the following POPI details: ',
                    file_Name: uploadedFile.name,
                    name_Surname: name_Surname == null ? ' ' : name_Surname,
                    contact_Number: contact_Number == null ? ' ' : contact_Number,
                    email_Address: email_Address == null ? ' ' : email_Address,
                    id_Number: id_Number == null ? ' ' : id_Number,
                    dob: dob == null ? ' ' : dob,
                   
                })
            })
        })
    }

    else

    {
        res.json({
            heading: `Cannot search file: ${req.files.file.name.split('.')[1]} . Fill the details in manually`,
            file_Name: '',
            name_Surname: '',
            contact_Number: '',
            email_Address: '',
            id_Number: '',
            dob: '',
        })
    }
})




module.exports = router