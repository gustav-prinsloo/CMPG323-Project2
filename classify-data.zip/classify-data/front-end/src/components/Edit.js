import React from 'react'

class Edit extends React.Component{
    constructor() {
        super()
        this.state = {
            heading: '',
            file_Name: '',
            name_Surname: '',
            contact_Number: '',
            email_Address: '',
            id_Number: '',
            dob: '',
            classified: false
        }

        this.handleChange = this.handleChange.bind(this)
        this.handleSubmit = this.handleSubmit.bind(this)
    }

    handleChange(e){
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    handleSubmit(e){
        e.preventDefault()
        let formData = new FormData()
        for (const [key, value] of Object.entries(this.state)){
            formData.append(key, value)
        }

        fetch('http://localhost:8080/api/save', {
            method: 'POST', 
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            this.setState({classified: true})
            console.log(data)
        })
        .catch(error => console.log(error))
    }

    componentDidMount() {
        this.setState({
            heading: this.props.heading,
            file_Name: this.props.fileName,
            name_Surname: this.props.nameAndSurname,
            contact_Number: this.props.contactNumber,
            email_Address: this.props.emailAddress,
            id_Number: this.props.idNumber,
            dob: this.props.dateOfBirth
        })
    }

    render() {
        if (!this.state.classified) {
            return (
                <div>
                    <h2> {this.state.heading} </h2>
                    <form onSubmit={this.handleSubmit}>
                        <h1> {this.state.heading} </h1>
                        <label>
                            Name and Surname: <input type="text" name="name_Surname" value={this.state.name_Surname} width="100%" onChange={this.handleChange}></input>
                        </label>
                        <br></br>
                        <label>
                            Contact Number: <input type="text" name="contact_Number" value={this.state.contact_Number} onChange={this.handleChange}></input>
                        </label>
                        <br></br>
                        <label>
                            Email Address: <input type="text" name="email_Address" value={this.state.email_Address} onChange={this.handleChange}></input>
                        </label>
                        <br></br>
                        <label>
                            ID Number: <input type="text" name="id_Number" value={this.state.id_Number} onChange={this.handleChange}></input>
                        </label>
                        <br></br>
                        <label>
                            Date of Birth: <input type="text" name="dob" value={this.state.dob} onChange={this.handleChange}></input>
                        </label>
                        <br></br>
                        <button> Save </button>
                    </form>                
                </div>  
            )
        }
        else {
            return (
                <div>
                    <h1>  Data stored on Database! </h1>
                </div>
            )
        }
    }
}

export default Edit