import React, { useState } from 'react';
import './Upload.css' 

import Edit from './Edit'

function Upload(){

    const [file, setFile] = useState('') 
    const [response, setResponse] = useState('') 

    const handleChange = (e) => {
        const fileToUpload = e.target.files[0]
        setFile(fileToUpload) 
    }

    const handleSubmit = (e) => {
        e.preventDefault() 

        if (file) {
            let formData = new FormData() 
            formData.append('file', file) 
    
            fetch('http://localhost:8080/api/upload', {
                method: 'POST',
                body: formData 
            })
            .then(response => response.json())
            .then(jsonResponse => setResponse(jsonResponse)) 
            .catch(error => console.log(error)) 
        }
    }

    if (!response) {
        return (
            <div className="Upload_Form">
                <h1> Select a data classification file </h1>
                <form method="POST" encType="multipart/form-data" onSubmit={handleSubmit}>
                    <input type="file" onChange={handleChange}></input><button> Upload </button>
                </form>
            </div>
        )        
    }
    else {
        return (
            <Edit

                heading={response.heading}
                file_Name={response.file_Name}
                name_Surname={response.name_Surname}
                contact_Number={response.contact_Number}
                email_Address={response.email_Address}
                id_Number={response.id_Number}
                dob={response.dob}
                processed={response.processed}
                saved={response.saved}
                
            />            
        )
    }
}

export default Upload