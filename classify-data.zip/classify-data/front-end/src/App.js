import Upload from './components/Upload'

function App() {
  return (
    <Upload />
  );
}

export default App;
