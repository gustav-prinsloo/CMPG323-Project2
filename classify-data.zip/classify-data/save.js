const router = require('express').Router()

const fileModel = require('./models/model')

router.post('/', (req, res) => {

    let formData = {

        file_Name: req.body.file_Name,
        name_Surname: req.body.name_Surname == '' ? false : true,
        contact_Number: req.body.contact_Number == '' ? false : true,
        email_Address: req.body.email_Address == '' ? false : true,
        id_Number: req.body.id_Number == '' ? false : true,
        dob: req.body.dob == '' ? false : true,
        
    }

    let fileMetadata = new fileModel(formData)

    fileMetadata.save((error, doc) => {

        if (error) {
                console.log(error)
        }

            res.json(doc)
    })
})




module.exports = router